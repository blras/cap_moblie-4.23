// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "WheeledVehicle.h"
#include "CapWheeledVehicle.generated.h"

/**
 * 
 */
UCLASS()
class CAP_MOBLIE_API ACapWheeledVehicle : public AWheeledVehicle
{
	GENERATED_BODY()

public:
	ACapWheeledVehicle();
protected:
	UPROPERTY(Category = Mesh, VisibleDefaultsOnly, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	class USkeletalMeshComponent* MeshComponent;
public:
	UFUNCTION(BlueprintNativeEvent, Category = Any)
	void Move();
	virtual void Tick(float DeltaTime) override;
	FORCEINLINE class USkeletalMeshComponent* GetMeshComponent() const { return MeshComponent; }
};
