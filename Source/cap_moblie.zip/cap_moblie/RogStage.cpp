// Fill out your copyright notice in the Description page of Project Settings.


#include "RogStage.h"
#include "RogObject.h"
#include "UObject/ConstructorHelpers.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SphereComponent.h"
#include "Components/InputComponent.h"
#include "Engine/CollisionProfile.h"
#include "Engine/StaticMesh.h"
#include "RogWolf.h"
#include "TimerManager.h"
// Sets default values
ARogStage::ARogStage()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	static ConstructorHelpers::FObjectFinder<UStaticMesh> StageMesh(TEXT("/Game/Meshes/Environment/SM_Env_Sand_Ground_06"));
	// Create the mesh component
	StageMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("StageMesh"));
	StageMeshComponent->SetupAttachment(RootComponent);
	StageMeshComponent->SetCollisionProfileName(UCollisionProfile::Pawn_ProfileName);
	StageMeshComponent->SetWorldScale3D(FVector(1, 1, 1));
	StageMeshComponent->SetStaticMesh(StageMesh.Object);
	
	ProxSphere = CreateDefaultSubobject<USphereComponent>(FName("ProxSphere"));
	ProxSphere->SetupAttachment(RootComponent);
	ProxSphere->SetSphereRadius(500.f);
	ProxSphere->OnComponentBeginOverlap.AddDynamic(this, &ARogStage::Prox);
	Length = 5632;
	MAXEnemy = 40;
}

// Called when the game starts or when spawned
void ARogStage::BeginPlay()
{
	//Super::BeginPlay();
	const FVector SpawnLocation = GetActorLocation();
	const FVector Dir = FVector(90.0f, 0.0f, 0.0f);
	const FRotator SpawnRotation = Dir.Rotation();
	UWorld* const World = GetWorld();
	bool isadjaceny_stage[4];
	for (int i = 0; i < 4; i++) 
	{
		float chance = 2.0f;
		if (FMath::RandRange(0.0f, chance)>1)
		{
			isadjaceny_stage[i] = true;
		}
	}
	int objectnum = FMath::RandRange(0, 5);
	
	for (int i = 0; i < objectnum; i++)
	{
		
	}
	const FVector ExitLocation = FVector(SpawnLocation.X - Length / 5, SpawnLocation.Y + Length / 2, 0);
	ProxSphere->SetWorldLocation(ExitLocation);
	if (World != NULL)
	{
		// spawn the projectile
		int numofob = FMath::RandRange(2, 5);
		for (int i = 0; i < numofob; i++)
		{
			//ARogObject* rogobject;
			//rogobject = World->SpawnActor< ARogObject >(SpawnLocation, SpawnRotation);
			//rogobject->SetObjectType(5-i);
		}
		//SetAdjaceny_Stages_Implementation();
	}
	spawn = true;
	//AddAdjaceny_Stages_Implementation();
	//GetWorldTimerManager().SetTimer(MemberTimerHandle, this, &ARogStage::SpawnEnemy, 1.0f, true, 1.0f);
}
// Called every frame
void ARogStage::Tick(float DeltaSeconds)
{

}
void ARogStage::Prox_Implementation(class UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult) 
{ 
	if (spawn == true)
	{
		//AddAdjaceny_Stages_Implementation();
	}
}
void ARogStage::AddAdjaceny_Stages_Implementation()
{
	spawn = false;
	UWorld* const world = GetWorld();
	if (world != NULL)
	{
		// spawn the projectile
		FVector SpawnLocation = GetActorLocation();
		SpawnLocation = FVector(SpawnLocation.X, SpawnLocation.Y + Length, 0);
		const FVector Dir = FVector(0.0f, 0.0f, 0.0f);
		const FRotator SpawnRotation = Dir.Rotation();
		world->SpawnActor<ARogStage>(SpawnLocation,SpawnRotation);
	}
}
void ARogStage::SpawnObject_Implementation()
{
	
}
void ARogStage::SpawnEnemy_Implementation()
{
	int count = CharacterinStage.Num();
	if (count < MAXEnemy)
	{
		UWorld* const world = GetWorld();
		//float length = Length;
		FVector SpawnLocation = FVector(FMath::RandRange(-Length / 2,Length/2), FMath::RandRange(-Length / 2, Length/2), 2);
		const FVector Dir = FVector(0.0f, 0.0f, 0.0f);
		const FRotator SpawnRotation = Dir.Rotation();
		ARogCharacter* enemy;
		enemy=world->SpawnActor<ARogWolf>(SpawnLocation, SpawnRotation);
		CharacterinStage.Add(enemy);
	}
	for (int i = 0; i < CharacterinStage.Num(); i++)
	{
		if (CharacterinStage[i] == nullptr)
		{
			CharacterinStage.RemoveAt(i);
		}
	}
}

