// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "RogCharacter.h"
#include "Enemy.generated.h"

UCLASS()
class CAP_MOBLIE_API AEnemy : public ARogCharacter
{
	GENERATED_BODY()
	UPROPERTY(Category = Mesh, VisibleDefaultsOnly, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	class AUserChar *User;
public:
	// Sets default values for this pawn's properties
	AEnemy();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
private:

public:	
	UPROPERTY(Category = Gameplay, EditAnywhere, BlueprintReadWrite)
	FVector GoalLoation;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Collision)
	class USphereComponent* PunchSphere;
	UFUNCTION(BlueprintNativeEvent, Category = Any)
	void Sight();
	UFUNCTION(BlueprintNativeEvent, Category = Any)
	void Hearing();
	UFUNCTION(BlueprintNativeEvent, Category = Any)
	void Move();
	// Called every frame
	UFUNCTION(BlueprintNativeEvent, Category = "Collision")
	void Punch(class UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
	UFUNCTION(BlueprintNativeEvent, Category = Any)
	void OnTarget(AActor* Actors);
	virtual void Tick(float DeltaTime) override;
	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

};
