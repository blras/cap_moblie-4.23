// Fill out your copyright notice in the Description page of Project Settings.


#include "RogCharacter.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/InputComponent.h"
#include "Components/SphereComponent.h"
#include "Components/ArrowComponent.h"
#include "Item.h"
#include "Gun.h"
#include "Knife.h"
#include "Bullet.h"
// Sets default values
ARogCharacter::ARogCharacter()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	MeshComponent = GetMesh();
	UCapsuleComponent* capsule = GetCapsuleComponent();
	capsule->SetCapsuleRadius(35);
	capsule->SetCapsuleHalfHeight(90);
	WeaponComponent = CreateDefaultSubobject<USkeletalMeshComponent>(FName("WeaponComponent"));
	AimComponent = CreateDefaultSubobject<UArrowComponent>(FName("AimComponent"));
	Hp = 5;
	MoveSpeed = 400;
	AttackRate = 1;
	bCanFire = true;
	bCanDmg = true;
	GetCharacterMovement()->MaxWalkSpeed = MoveSpeed;
	range = 100;
}

// Called when the game starts or when spawned
void ARogCharacter::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ARogCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

// Called to bind functionality to input
void ARogCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}
void ARogCharacter::Attack(FVector FireDirection)
{
	if (bCanFire == true)
	{
		// If we are pressing fire stick in a direction
		if (FireDirection.SizeSquared() > 0.0f)
		{

			UWorld* const World = GetWorld();
			const FRotator FireRotation = FireDirection.Rotation();
			const FVector SpawnLocation = GetActorLocation(); //+ FireRotation.RotateVector(GunOffset);
			// Spawn projectile at an offset from this pawn
			/*if (Weapon == nullptr)
			{
				//PlayAnimMontage(Animmontage, 1);
			}
			else if (Weapon->GetClass() == AKnife::StaticClass())
			{
				//PlayAnimMontage(snapAnimmontage, 1.5);
			}
			else
			{
				//PlayAnimMontage(GunAnimmontage, 1);
				FVector gunoffset = Cast<AGun>(Weapon)->GunOffset;
				if (World != NULL)
				{
					// spawn the projectile
					World->SpawnActor<ABullet>(SpawnLocation + FireRotation.RotateVector(gunoffset), FireRotation);
					if (FireSound != nullptr)
					{
						UGameplayStatics::PlaySoundAtLocation(this, FireSound, GetActorLocation());
					}
				}

			}*/
			PlayAnimMontage(Animmontage, 1);
			//FVector gunoffset = Cast<AGun>(Weapon)->GunOffset;
			FVector gunoffset = FVector(70,0,0);
			if (World != NULL)
			{
				// spawn the projectile
				World->SpawnActor<ABullet>(SpawnLocation + FireRotation.RotateVector(gunoffset), FireRotation);
				//if (FireSound != nullptr)
				//{
					//UGameplayStatics::PlaySoundAtLocation(this, FireSound, GetActorLocation());
				//}
			}

			bCanFire = false;
			World->GetTimerManager().SetTimer(TimerHandle_ShotTimerExpired, this, &ARogCharacter::AttackTimerExpired, AttackRate);
			SetActorRotation(FireRotation);
			// try and play the sound if specified
		//	if (FireSound != nullptr)
			//{
				//UGameplayStatics::PlaySoundAtLocation(this, FireSound, GetActorLocation());
			//}

			bCanFire = false;
		}
	}
}
void ARogCharacter::AttackTimerExpired()
{
	bCanFire = true;
	//if (Weapon == nullptr)
	{
		bCanDmg = true;
	}
//	else
	{
		//Weapon->CanDmg();
	}
}
void ARogCharacter::Death()
{
	Destroy();
}
void ARogCharacter::Equip_Implementation(AItem* item)
{
	/*if (Weapon == nullptr)
	{
		FName handsocket = TEXT("Hand_R");
		FRotator SpawnRotation;
		Weapon = item;
		Weapon->AttachToComponent(MeshComponent, FAttachmentTransformRules::KeepWorldTransform, handsocket);
		if (item->GetClass() == AKnife::StaticClass())
		{
			SpawnRotation = FRotator(0, -90, 90);
			Weapon->SetActorRelativeLocation(FVector(-12, 0, -3));
		}
		else
		{
			SpawnRotation = FRotator(0, -100, 185);
			Weapon->SetActorRelativeLocation(FVector(-5, 0, -5));
		}
		Weapon->SetActorRelativeRotation(SpawnRotation);
		Weapon->IsUse = true;
		Weapon->faction = faction;
		Weapon->Setting();
		range = Weapon->range;
		AttackRate = Weapon->AttackRate;
		bCanDmg = false;
	}
	else
	{
		
	}*/
}
void ARogCharacter::HitDamage_Implementation(int damage, FVector dir)
{
	FVector knockback = dir;
	RootComponent->MoveComponent(dir, GetActorLocation().Rotation(), true);
	Hp -= damage;
	//if(target)
}
