// Fill out your copyright notice in the Description page of Project Settings.


#include "Enemy.h"
#include "UObject/ConstructorHelpers.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/InputComponent.h"
#include "Components/SphereComponent.h"
#include "Components/CapsuleComponent.h"
#include "Engine/CollisionProfile.h"
#include "TimerManager.h"
#include "Kismet/GameplayStatics.h"
#include "UserChar.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Item.h"
#include "Gun.h"
#include "Cap_AIController.h"
// Sets default values
AEnemy::AEnemy()
{
 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	static ConstructorHelpers::FObjectFinder<USkeletalMesh> Mesh(TEXT("/Game/meshes/Characters/SK_BR_Character_Big_Ork_01"));
	static ConstructorHelpers::FObjectFinder<UClass> AnimFinder(TEXT("Class'/Game/polymace/polymacebp/Serath_AnimBlueprint.Serath_AnimBlueprint_C'"));
	
	// Create the mesh component
	MeshComponent->SetSkeletalMesh(Mesh.Object);
	MeshComponent->SetupAttachment(RootComponent);
	MeshComponent->SetCollisionProfileName(UCollisionProfile::Pawn_ProfileName);
	MeshComponent->SetWorldScale3D(FVector(1, 1, 1));
	MeshComponent->RelativeRotation = FRotator(0.f, -90.f, 0.f);
	MeshComponent->RelativeLocation = FVector(0, 0, -90);
	if (AnimFinder.Object)
	{
		UClass* Anim = AnimFinder.Object;
		MeshComponent->SetAnimInstanceClass(Anim);
	}
	MeshComponent->SetGenerateOverlapEvents(true);

	static ConstructorHelpers::FObjectFinder<UAnimMontage> animmontage(TEXT("/Game/polymace/Primary_Attack_A_Medium_Montage"));
	//static ConstructorHelpers::FObjectFinder<UAnimMontage> snapanimmontage(TEXT("/Game/Char/PolyChar/anim/A_SW_Attack_01_Montage"));
	//static ConstructorHelpers::FObjectFinder<UAnimMontage> gunanimmontage(TEXT("/Game/Char/PolyChar/anim/polychar_shot_Montage"));
	Animmontage = animmontage.Object;
	//snapAnimmontage = snapanimmontage.Object;
	//GunAnimmontage = gunanimmontage.Object;
	const USkeletalMeshSocket* HandSocket;
	HandSocket = MeshComponent->GetSocketByName(TEXT("LeftHand"));
	FName handsocket = TEXT("LeftHand");
	PunchSphere = CreateDefaultSubobject<USphereComponent>(FName("PunchSphere"));
	PunchSphere->AttachToComponent(MeshComponent, FAttachmentTransformRules::KeepWorldTransform, handsocket);
	PunchSphere->SetSphereRadius(2.f);
	PunchSphere->OnComponentBeginOverlap.AddDynamic(this, &AEnemy::Punch);
	Hp = 500;
	MoveSpeed = 300;
	faction = "Enemy";
	AIControllerClass = ACap_AIController::StaticClass();
	GoalLoation = FVector(0,0,0);
	range = 150;
}

// Called when the game starts or when spawned
void AEnemy::BeginPlay()
{
	Super::BeginPlay();
	GoalLoation = GetActorLocation();
}

// Called every frame
void AEnemy::Tick(float DeltaTime)
{
	if (Hp <= 0)
	{
		//Destroy();
		MeshComponent->SetCollisionEnabled(ECollisionEnabled::PhysicsOnly);
		MeshComponent->SetSimulatePhysics(true);
		//InputEnabled();
		Hp--;
		if (Hp < -100)
		{
			Destroy();
		}
	}
	else
	{
		//Sight();
		if (bCanFire == true)
		{
			Move();
		}
	}
}
// Called to bind functionality to input
void AEnemy::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

void AEnemy::Punch_Implementation(class UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (bCanFire == false)
	{
		if (bCanDmg == true)
		{
			if (Target == nullptr)
			{
				return;
			}
			Target->Hp -= 1;
			bCanDmg = false;
		}
	}
}

void AEnemy::Sight_Implementation()
{
	FHitResult hit;
	FVector strace = GetActorLocation() + (GetActorForwardVector() * 60);
	FVector etrace = strace + (GetActorForwardVector() * 1500);
	GetWorld()->LineTraceSingleByObjectType(hit, strace, etrace, ECollisionChannel::ECC_Pawn);
	if (hit.GetActor() == nullptr)
	{
		return;
	}
	else
	{
		if (Cast<AUserChar>(hit.GetActor()) == nullptr)
		{
			return;
		}
		Target = Cast<AUserChar>(hit.GetActor());
	}
}

void AEnemy::OnTarget_Implementation(AActor* Actors)
{
	Target =Cast<AUserChar>(Actors);
}
void AEnemy::Hearing_Implementation()
{
}
void AEnemy::Move_Implementation()
{
	FVector Movement;
	if (Target)
	{
		Movement = Target->GetActorLocation() - GetActorLocation();
		if (Movement.Size() > range)
		{
			Movement.GetClampedToMaxSize(1);
			SetActorRotation(Movement.Rotation());
			AddMovementInput(Movement, MoveSpeed);
		}
		else
		{
			Attack(Movement);
		}
	}
	else if(GoalLoation != GetActorLocation())
	{
		Movement = GoalLoation - GetActorLocation();
		if (Movement.Size() > range) 
		{
			Movement.GetClampedToMaxSize(1);
			FRotator Rotation = FRotator(0, Movement.Rotation().Yaw, 0);
			SetActorRotation(Rotation);
			AddMovementInput(Movement, MoveSpeed);
		}
	}
}

