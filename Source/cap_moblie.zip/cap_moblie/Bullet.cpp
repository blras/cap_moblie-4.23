// Fill out your copyright notice in the Description page of Project Settings.


#include "Bullet.h"
#include "UObject/ConstructorHelpers.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/CollisionProfile.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "RogCharacter.h"
// Sets default values
ABullet::ABullet()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	static ConstructorHelpers::FObjectFinder<UStaticMesh> ItemMesh(TEXT("/Game/effect/bullet/bullet"));
	BulletMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("ItemMesh"));
	BulletMeshComponent->SetWorldScale3D(FVector(8, 8, 8));
	BulletMeshComponent->SetStaticMesh(ItemMesh.Object);
	BulletMeshComponent->SetupAttachment(RootComponent);
	BulletMeshComponent->BodyInstance.SetCollisionProfileName("Projectile");
	BulletMeshComponent->OnComponentHit.AddDynamic(this, &ABullet::OnHit);		
	// set up a notification for when this component hits something
	RootComponent = BulletMeshComponent;

	BulletMovement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileMovement0"));
	BulletMovement->UpdatedComponent = BulletMeshComponent;
	BulletMovement->InitialSpeed = 2048.f;
	BulletMovement->MaxSpeed = 2048.f;
	BulletMovement->bRotationFollowsVelocity = true;
	BulletMovement->bShouldBounce = false;
	BulletMovement->ProjectileGravityScale = 0.f; // No gravity

	// Die after 3 seconds by default
	InitialLifeSpan = 3.0f;
}

// Called when the game starts or when spawned

// Called every frame
void ABullet::OnHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit)
{
	if (Cast<ARogCharacter>(OtherActor) == nullptr)
	{
		return;
	}
	ARogCharacter* target = Cast<ARogCharacter>(OtherActor);
	target->HitDamage(1, GetActorForwardVector());
	Destroy();
}

