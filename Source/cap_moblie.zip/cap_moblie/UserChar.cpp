// Fill out your copyright notice in the Description page of Project Settings.


#include "UserChar.h"
#include "cap_moblieProjectile.h"
#include "TimerManager.h"
#include "UObject/ConstructorHelpers.h"
#include "Camera/CameraComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/InputComponent.h"
#include "Components/SphereComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/ArrowComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Engine/CollisionProfile.h"
#include "Engine/StaticMesh.h"
#include "Kismet/GameplayStatics.h"
#include "Sound/SoundBase.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Enemy.h"
#include "Item.h"
#include "Gun.h"
#include "Engine.h"


const FName AUserChar::MoveForwardBinding("MoveForward");
const FName AUserChar::MoveRightBinding("MoveRight");
const FName AUserChar::LookForwardBinding("LookForward");
const FName AUserChar::TurnRightBinding("TurnRight");

// Sets default values
AUserChar::AUserChar()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	static ConstructorHelpers::FObjectFinder<USkeletalMesh> UserMesh(TEXT("/Game/Meshes/Characters/SK_Character_Rock_Golem"));
	static ConstructorHelpers::FObjectFinder<UClass> AnimFinder(TEXT("Class'/Game/polytwin/polytwinbp/Twinblast_AnimBlueprint.Twinblast_AnimBlueprint_C'"));
	static ConstructorHelpers::FObjectFinder<USkeletalMesh> WeaponMesh(TEXT("/Game/Meshes/Weapons/SK_Wep_Revolver_02"));
	// Create the mesh component
	MeshComponent->SetSkeletalMesh(UserMesh.Object);
	MeshComponent->SetupAttachment(RootComponent);
	MeshComponent->SetCollisionProfileName(UCollisionProfile::Pawn_ProfileName);
	MeshComponent->SetWorldScale3D(FVector(1, 1, 1));
	if (AnimFinder.Object)
	{
		UClass* Anim = AnimFinder.Object;
		MeshComponent->SetAnimInstanceClass(Anim);
	}
	MeshComponent->RelativeRotation = FRotator(0.f, -90.f, 0.f);
	MeshComponent->RelativeLocation = FVector(0, 0, -90);
	WeaponComponent->SetSkeletalMesh(WeaponMesh.Object);
	// Cache our sound effect
	static ConstructorHelpers::FObjectFinder<USoundBase> FireAudio(TEXT("/Game/TwinStick/Audio/TwinStickFire.TwinStickFire"));
//	FireSound = FireAudio.Object;

	static ConstructorHelpers::FObjectFinder<UAnimMontage> animmontage(TEXT("/Game/polytwin/Primary_Fire_Med_A_Montage"));
	Animmontage = animmontage.Object;
	//snapAnimmontage = snapanimmontage.Object;
	//GunAnimmontage = Gunanimmontage.Object;

	GetCharacterMovement()->bOrientRotationToMovement = true;
	GetCharacterMovement()->RotationRate = FRotator(0.0f, 540.0f, 0.0f);

	// Create a camera boom...
	CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
	CameraBoom->SetupAttachment(RootComponent);
	CameraBoom->bAbsoluteRotation = true; // Don't want arm to rotate when ship does
	CameraBoom->TargetArmLength = 500.f;
	CameraBoom->bUsePawnControlRotation=true;
	CameraBoom->RelativeLocation = FVector(0, 0,120);

	// Create a camera...
	CameraComponent = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
	CameraComponent->SetupAttachment(CameraBoom, USpringArmComponent::SocketName);
	CameraComponent->bUsePawnControlRotation = false;	// Camera does not rotate relative to arm

	//Set Weapons Location
	const USkeletalMeshSocket* HandSocket;
	HandSocket = MeshComponent->GetSocketByName(TEXT("Hand_R"));
	FName handsocket = TEXT("Hand_R");
	WeaponComponent->AttachToComponent(MeshComponent, FAttachmentTransformRules::KeepWorldTransform, handsocket);
	WeaponComponent->RelativeLocation=FVector(-8, -5, -5);
	WeaponComponent->RelativeRotation = FRotator(180,110,-20);
	FName leftsocket = TEXT("Hand_L");
	LeftWeaponComponent = CreateDefaultSubobject<USkeletalMeshComponent>(FName("LeftWeaponComponent"));
	LeftWeaponComponent->SetSkeletalMesh(WeaponMesh.Object);
	LeftWeaponComponent->AttachToComponent(MeshComponent, FAttachmentTransformRules::KeepWorldTransform, leftsocket);
	LeftWeaponComponent->RelativeLocation = FVector(8, 5, 5);
	LeftWeaponComponent->RelativeRotation = FRotator(0, -70, -20);
	//PunchSphere->OnComponentBeginOverlap.AddDynamic(this, &AUserChar::Prox);
	// Movement
	MoveSpeed = 600.0f;
	bUseControllerRotationYaw = false;
	Hp = 5;
	faction = "User";

	BaseTurnRate = 45.f;
	BaseLookUpRate = 45.f;

	AimComponent->SetupAttachment(CameraComponent);
	AimComponent->RelativeLocation = FVector(0, 0, 120);
}

void AUserChar::SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent)
{
	check(PlayerInputComponent);

	// set up gameplay key bindings
	PlayerInputComponent->BindAxis(MoveForwardBinding);
	PlayerInputComponent->BindAxis(MoveRightBinding);
	PlayerInputComponent->BindAxis(LookForwardBinding);
	PlayerInputComponent->BindAxis(TurnRightBinding);

	PlayerInputComponent->BindAxis("MoveForward", this, &AUserChar::MoveForward);
	PlayerInputComponent->BindAxis("MoveRight", this, &AUserChar::MoveRight);

	PlayerInputComponent->BindAxis("Turn",this, &APawn::AddControllerYawInput);
	PlayerInputComponent->BindAxis("TurnRight", this, &AUserChar::TurnAtRate);
	PlayerInputComponent->BindAxis("LookUp", this, &APawn::AddControllerPitchInput);
	PlayerInputComponent->BindAxis("LookForward", this, &AUserChar::LookUpAtRate);

}

// Called when the game starts or when spawned
void AUserChar::BeginPlay()
{
	Super::BeginPlay();
}
// Called every frame
void AUserChar::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);
	// Find movement direction
	const float ForwardValue = GetInputAxisValue(MoveForwardBinding);
	const float RightValue = GetInputAxisValue(MoveRightBinding);

	// Clamp max size so that (X=1, Y=1) doesn't cause faster movement in diagonal directions
	const FVector MoveDirection = FVector(ForwardValue, RightValue, 0.f).GetClampedToMaxSize(1.0f);

	// Calculate  movement
	const FVector Movement = MoveDirection * MoveSpeed * DeltaSeconds;
	const FRotator TurnRotation = FRotator(0, GetControlRotation().Yaw, 0);
	// If non-zero size, move this actor
	//if (bCanFire == true)
	//{
	TRDebug = TurnRotation;
	FHitResult Hit(1.f);
	SetActorRotation(TurnRotation);
		if (Hit.IsValidBlockingHit())
		{
			const FVector Normal2D = Hit.Normal.GetSafeNormal2D();
			const FVector Deflection = FVector::VectorPlaneProject(Movement, Normal2D) * (1.f - Hit.Time);
			SetActorRotation(TurnRotation);
		}
	//}
	Aim();
	// Create fire direction vector
	//const float FireForwardValue = GetInputAxisValue(LookForwardBinding);
	//const float FireRightValue = GetInputAxisValue(TurnRightBinding);
	//const FVector FireDirection = FVector(FireForwardValue, FireRightValue, 0.f);

	// Try and fire a shot
	//Attack(FireDirection);
}

void AUserChar::Prox_Implementation(class UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (bCanFire==false)
	{
		if (bCanDmg == true)
		{
			if (Cast<AEnemy>(OtherActor) == nullptr)
			{
				return;
			}
			AEnemy* target = Cast<AEnemy>(OtherActor);
			target->Hp -= 1;
			bCanDmg = false;
		}
	}
}
void AUserChar::TurnAtRate(float Rate)
{
	AddControllerYawInput(Rate * BaseTurnRate * GetWorld()->GetDeltaSeconds());
}
void AUserChar::LookUpAtRate(float Rate)
{
	AddControllerPitchInput(Rate * BaseLookUpRate * GetWorld()->GetDeltaSeconds()*-1);
}
void AUserChar::MoveForward(float Value)
{
	if ((Controller != NULL) && (Value != 0.0f))
	{
		// find out which way is forward
		const FRotator Rotation = Controller->GetControlRotation();
		const FRotator YawRotation(0, Rotation.Yaw, 0);

		// get forward vector
		const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);
		AddMovementInput(Direction, Value);
	}
}

void AUserChar::MoveRight(float Value)
{
	if ((Controller != NULL) && (Value != 0.0f))
	{
		// find out which way is right
		const FRotator Rotation = Controller->GetControlRotation();
		const FRotator YawRotation(0, Rotation.Yaw, 0);

		// get right vector 
		const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);
		// add movement in that direction
		AddMovementInput(Direction, Value);
	}
}
void AUserChar::Aim_Implementation()
{
	FHitResult hit;
	//FVector strace = GetActorLocation() + (GetActorForwardVector() * 60);
	//FVector etrace = strace + (GetActorForwardVector() * 1500);
	FVector strace = GetActorLocation() + (AimComponent->GetForwardVector() * 60);
	FVector etrace = strace + (AimComponent->GetForwardVector() * 1500);
	GetWorld()->LineTraceSingleByObjectType(hit, strace, etrace, ECollisionChannel::ECC_Pawn);
	if (hit.GetActor() == nullptr)
	{
		return;
	}
	else
	{
		if (Cast<AEnemy>(hit.GetActor()) == nullptr)
		{
			return;
		}
		GEngine->AddOnScreenDebugMessage(-1, 15.0f, FColor::Red, "on target!");
		AEnemy* target = Cast<AEnemy>(hit.GetActor());
		FVector Movement = target->GetActorLocation() - GetActorLocation();
		Attack(Movement);
	}
}
// Called to bind functionality to input

