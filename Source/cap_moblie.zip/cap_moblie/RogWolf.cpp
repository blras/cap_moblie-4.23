// Fill out your copyright notice in the Description page of Project Settings.


#include "RogWolf.h"
#include "UObject/ConstructorHelpers.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/InputComponent.h"
#include "Components/SphereComponent.h"
#include "Components/CapsuleComponent.h"
#include "Engine/CollisionProfile.h"
ARogWolf::ARogWolf()
{
	PrimaryActorTick.bCanEverTick = true;
	static ConstructorHelpers::FObjectFinder<USkeletalMesh> Mesh(TEXT("/Game/Char/PolyArtWolf/Meshes/SK_Wolf"));
	static ConstructorHelpers::FObjectFinder<UClass> AnimFinder(TEXT("Class'/Game/Char/PolyArtWolf/Animations/animbp_wolf.animbp_wolf_C'"));
	// Create the mesh component
	MeshComponent->SetSkeletalMesh(Mesh.Object);
	MeshComponent->SetupAttachment(RootComponent);
	MeshComponent->SetCollisionProfileName(UCollisionProfile::Pawn_ProfileName);
	MeshComponent->SetWorldScale3D(FVector(0.8, 0.8, 0.8));
	MeshComponent->RelativeRotation = FRotator(0.f, -90.f, 0.f);
	MeshComponent->RelativeLocation = FVector(0, 0, -44);
	if (AnimFinder.Object)
	{
		UClass* Anim = AnimFinder.Object;
		MeshComponent->SetAnimInstanceClass(Anim);
	}
	MeshComponent->SetGenerateOverlapEvents(true);

	Hp = 3;
	MoveSpeed = 150;
	faction = "Enemy";
}