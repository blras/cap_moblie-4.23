// Fill out your copyright notice in the Description page of Project Settings.


#include "RogVarActor.h"
#include "UObject/ConstructorHelpers.h"
#include "Components/StaticMeshComponent.h"
#include "Components/InputComponent.h"
#include "Engine/CollisionProfile.h"
#include "Engine/StaticMesh.h"
#include "EngineUtils.h"
// Sets default values
ARogVarActor::ARogVarActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	static ConstructorHelpers::FObjectFinder<UStaticMesh> deco0Mesh(TEXT("/Game/Meshes/Environment/SM_Env_Cliff_Curve_01"));
	ObjectMeshPath.Add(deco0Mesh.Object);
	static ConstructorHelpers::FObjectFinder<UStaticMesh> deco1Mesh(TEXT("/Game/Meshes/Environment/SM_Env_Cliff_Curve_02"));
	ObjectMeshPath.Add(deco1Mesh.Object);
	static ConstructorHelpers::FObjectFinder<UStaticMesh> deco2Mesh(TEXT("/Game/Meshes/Environment/SM_Env_Butte_01"));
	ObjectMeshPath.Add(deco2Mesh.Object);
	static ConstructorHelpers::FObjectFinder<UStaticMesh> deco3Mesh(TEXT("/Game/Meshes/Environment/SM_Env_Butte_02"));
	ObjectMeshPath.Add(deco3Mesh.Object);
	static ConstructorHelpers::FObjectFinder<UStaticMesh> deco4Mesh(TEXT("/Game/Meshes/Environment/SM_Env_Butte_03"));
	ObjectMeshPath.Add(deco4Mesh.Object);
	static ConstructorHelpers::FObjectFinder<UStaticMesh> deco5Mesh(TEXT("/Game/Meshes/Environment/SM_Env_Butte_04"));
	ObjectMeshPath.Add(deco5Mesh.Object);
	static ConstructorHelpers::FObjectFinder<UStaticMesh> deco6Mesh(TEXT("/Game/Meshes/Environment/SM_Env_Cliff_Cap_01"));
	ObjectMeshPath.Add(deco6Mesh.Object);
	static ConstructorHelpers::FObjectFinder<UStaticMesh> deco7Mesh(TEXT("/Game/Meshes/Environment/SM_Env_Cliff_Cap_02"));
	ObjectMeshPath.Add(deco7Mesh.Object);
	static ConstructorHelpers::FObjectFinder<UStaticMesh> wall0Mesh(TEXT("/Game/Meshes/Environment/SM_Env_Butte_01"));
	WallMeshPath.Add(wall0Mesh.Object);
	static ConstructorHelpers::FObjectFinder<UStaticMesh> wall1Mesh(TEXT("/Game/Meshes/Environment/SM_Env_Butte_01"));
	WallMeshPath.Add(wall1Mesh.Object);
	static ConstructorHelpers::FObjectFinder<UStaticMesh> wall2Mesh(TEXT("/Game/Meshes/Environment/SM_Env_Butte_01"));
	WallMeshPath.Add(wall2Mesh.Object);
	static ConstructorHelpers::FObjectFinder<UStaticMesh> wall3Mesh(TEXT("/Game/Meshes/Environment/SM_Env_Butte_01"));
	WallMeshPath.Add(wall3Mesh.Object);
	static ConstructorHelpers::FObjectFinder<UStaticMesh> wall4Mesh(TEXT("/Game/Meshes/Environment/SM_Env_Butte_01"));
	WallMeshPath.Add(wall4Mesh.Object);
	static ConstructorHelpers::FObjectFinder<UStaticMesh> wall5Mesh(TEXT("/Game/Meshes/Environment/SM_Env_Butte_01"));
	WallMeshPath.Add(wall5Mesh.Object);
	static ConstructorHelpers::FObjectFinder<UStaticMesh> wall6Mesh(TEXT("/Game/Meshes/Environment/SM_Env_Butte_01"));
	WallMeshPath.Add(wall6Mesh.Object);
}

// Called when the game starts or when spawned
void ARogVarActor::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ARogVarActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}
void ARogVarActor::GetVarMesh_Implementation(int num)
{
//
}
