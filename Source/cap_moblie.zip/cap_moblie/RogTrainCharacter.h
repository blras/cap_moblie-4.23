// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "RogCharacter.h"
#include "RogTrainCharacter.generated.h"

/**
 * 
 */
UCLASS()
class CAP_MOBLIE_API ARogTrainCharacter : public ARogCharacter
{
	GENERATED_BODY()
	
};
