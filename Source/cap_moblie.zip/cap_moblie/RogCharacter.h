// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "RogCharacter.generated.h"

UCLASS()
class CAP_MOBLIE_API ARogCharacter : public ACharacter
{
	GENERATED_BODY()
public:
	// Sets default values for this character's properties
	ARogCharacter();

protected:
	// Called when the game starts or when spawned
	UPROPERTY(Category = Mesh, VisibleDefaultsOnly, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	class USkeletalMeshComponent* MeshComponent;
	UPROPERTY(Category = Mesh, VisibleDefaultsOnly, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	class USkeletalMeshComponent* WeaponComponent;
	UPROPERTY(Category = Mesh, VisibleDefaultsOnly, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	class UArrowComponent* AimComponent;
	virtual void BeginPlay() override;
	uint32 bCanFire : 1;
	uint32 bCanDmg : 1;
	FTimerHandle TimerHandle_ShotTimerExpired;
	FTimerHandle TimerHandle_DeathTimerExpired;
	UAnimMontage* Animmontage;
	UAnimMontage* snapAnimmontage;
	UAnimMontage* GunAnimmontage;
public:	
	FString faction;
	int32 range;
	// Called every frame
	virtual void Tick(float DeltaTime) override;
	UPROPERTY(Category = Mesh, EditAnywhere, BlueprintReadWrite, meta = (AllowPrivateAccess = "true"))
	class ARogCharacter* Target;
	UPROPERTY(Category = Mesh, VisibleDefaultsOnly, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	class AItem* EItem;
	UPROPERTY(Category = Gameplay, EditAnywhere, BlueprintReadWrite)
	float AttackRate;
	/*UFUNCTION(BlueprintNativeEvent, Category = Any)
	void HitDamage(int damage, FVector dir);*/
	/* The speed our ship moves around the level */
	UPROPERTY(Category = Gameplay, EditAnywhere, BlueprintReadWrite)
	float MoveSpeed;
	UPROPERTY(Category = Gameplay, EditAnywhere, BlueprintReadWrite)
	int Hp;
	/** Sound to play each time we fire */
	UPROPERTY(Category = Audio, EditAnywhere, BlueprintReadWrite)
	class USoundBase* AttackSound;

	UFUNCTION(BlueprintNativeEvent, Category = Any)
	void HitDamage(int damage, FVector dir);
	/* Fire a shot in the specified direction */
	void Attack(FVector FireDirection);
	/* Handler for the fire timer expiry */
	void AttackTimerExpired();

	void Death();
	UFUNCTION(BlueprintNativeEvent, Category = Any)
	void Equip(AItem* item);
	// Called to bind functionality to input
	FORCEINLINE class USkeletalMeshComponent* GetMeshComponent() const { return MeshComponent; }
	FORCEINLINE class USkeletalMeshComponent* GetWeaponComponent() const { return WeaponComponent; }
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

};
