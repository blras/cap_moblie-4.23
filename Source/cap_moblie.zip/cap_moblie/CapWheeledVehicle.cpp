// Fill out your copyright notice in the Description page of Project Settings.


#include "CapWheeledVehicle.h"
#include "UObject/ConstructorHelpers.h"
#include "Components/StaticMeshComponent.h"
#include "Components/InputComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/CollisionProfile.h"

ACapWheeledVehicle::ACapWheeledVehicle()
{
	PrimaryActorTick.bCanEverTick = true;
	static ConstructorHelpers::FObjectFinder<USkeletalMesh>Mesh(TEXT("/Game/Meshes/Vehicles_Rigged/SK_Veh_Train_01"));
	//static ConstructorHelpers::FObjectFinder<UClass> AnimFinder(TEXT("Class'/Game/Meshes/TrainAnimbpTest.TrainAnimbpTest_C'"));
	// Create the mesh component
	MeshComponent = GetMesh();
	MeshComponent->SetSkeletalMesh(Mesh.Object);
	MeshComponent->SetupAttachment(RootComponent);
	MeshComponent->SetCollisionProfileName(UCollisionProfile::Pawn_ProfileName);
	MeshComponent->SetWorldScale3D(FVector(1, 1, 1));
	MeshComponent->RelativeRotation = FRotator(0.f, -90.f, 0.f);
	MeshComponent->RelativeLocation = FVector(0, 0, -90);
/*	if (AnimFinder.Object)
	{
		UClass* Anim = AnimFinder.Object;
		MeshComponent->SetAnimInstanceClass(Anim);
	}*/
}
void ACapWheeledVehicle::Tick(float DeltaTime)
{
	//Move();
}
void ACapWheeledVehicle::Move_Implementation()
{
	float MoveSpeed = 100;
	FVector Movement = FVector(1, 0, 0);
			Movement.GetClampedToMaxSize(1);
			SetActorRotation(Movement.Rotation());
			AddMovementInput(Movement, MoveSpeed);
}