// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "cap_moblie.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, cap_moblie, "cap_moblie" );

DEFINE_LOG_CATEGORY(Logcap_moblie)
 