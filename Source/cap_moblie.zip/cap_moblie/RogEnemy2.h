// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Enemy.h"
#include "RogEnemy2.generated.h"

/**
 * 
 */
UCLASS()
class CAP_MOBLIE_API ARogEnemy2 : public AEnemy
{
	GENERATED_BODY()
	
};
